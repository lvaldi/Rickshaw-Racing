# Rickshaw Racing

A racing game made in Unity (still a work-in-progress).

This repo is kept separate from the main repo, so that there is a stable(ish) build that I can show to people. Because of that, it is not always fully up-to-date.

This game is under development by me, [Richard Le](https://github.com/LegendaryLe), Michael Ge, [Juan Lee](https://github.com/JuanLeee), and [Darren Fu](https://github.com/lvaldi).

This project also uses assets from the [Racing Kit by Kenney](https://kenney.nl/assets/racing-kit).